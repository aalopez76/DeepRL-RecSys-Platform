# DeepRL-RecSys-Platform

[![CI](https://github.com/aalopez76/DeepRL-RecSys-Platform/actions/workflows/ci.yml/badge.svg)](https://github.com/aalopez76/DeepRL-RecSys-Platform/actions)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

> End-to-end platform for Deep RL-based Recommender Systems with reproducible
> Off-Policy Evaluation (OPE), serving, and diagnostics.

## ✨ Features

- **Reproducible experiments** — deterministic config inheritance (default < experiment < CLI), global seeding
- **Schema-driven data validation** — `bandit_v1` / `sequential_v1` with propensity policy enforcement
- **Off-Policy Evaluation** — IPS, Doubly Robust, diagnostics with `ReliabilityVerdict`
- **Canonical artifacts** — metadata + checksums + schema guards
- **FastAPI serving** — `/health`, `/info`, `/recommend` endpoints
- **Plugin-ready** — lazy registry + opt-in entry-point loading
- **Extras** — `[aws]`, `[llm]`, `[tf]`, `[explain]`, `[reports]`, `[docs]`, `[dev]`

## 🚀 Quickstart

```bash
# Install (minimal, no GPU/LLM dependencies)
pip install poetry
poetry install --with dev

# Run the happy path
deeprl-recsys prepare  --config configs/experiments/exp1_dqn_movielens.yaml
deeprl-recsys train    --config configs/experiments/exp1_dqn_movielens.yaml
deeprl-recsys evaluate --config configs/experiments/exp1_dqn_movielens.yaml
deeprl-recsys export   --config configs/experiments/exp1_dqn_movielens.yaml
deeprl-recsys serve    --artifact artifacts/models/latest
```

## 🏗️ Architecture

```
configs/          ← YAML configuration (agents, datasets, experiments)
src/deeprl_recsys/
  core/           ← Single Source of Truth (config, schema, artifacts, registry)
  agents/         ← BaseAgent + baselines + DQN/PPO/SAC
  training/       ← Trainer loop, callbacks, session manager
  data_pipeline/  ← ETL, validation, transforms, splits
  evaluation/     ← Metrics + OPE (estimators + diagnostics)
  environment/    ← Gym wrappers + simulators
  serving/        ← FastAPI app + runtime + middleware
  explainability/ ← SHAP / attention (opt-in)
  cli.py          ← Typer CLI entry point
pipelines/        ← Official orchestration scripts
tests/            ← unit / integration / smoke / e2e
```

## 🧪 Testing

```bash
# Unit + integration + smoke
pytest -m "unit or integration or smoke" -v

# Full e2e (nightly)
pytest -m e2e -v

# Coverage report
pytest --cov=deeprl_recsys --cov-report=term-missing
```

## 📖 Documentation

```bash
# Build Sphinx docs (requires [docs] extra)
poetry install -E docs
cd docs && make html
```

## ⚠️ OPE Limitations

Off-Policy Evaluation estimates are **only reliable** when propensity scores are
available and pass diagnostic checks (ESS, clipping rate, overlap). Results
without propensity are automatically flagged as unreliable or blocked depending
on the configured policy (`mark_unreliable` | `block_ope`).

## 📄 License

[MIT](LICENSE)
