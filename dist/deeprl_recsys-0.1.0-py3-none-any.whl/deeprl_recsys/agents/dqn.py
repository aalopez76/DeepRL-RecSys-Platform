"""DQN Agent — stub with BaseAgent interface.

Full implementation will be added in a later phase.
"""

from __future__ import annotations

from typing import Any

from deeprl_recsys.agents.base import BaseAgent


class DQNAgent(BaseAgent):
    """Deep Q-Network agent (stub)."""

    def __init__(self, **kwargs: Any) -> None:
        self._config = kwargs

    def act(self, observation: dict[str, Any], candidates: list[int]) -> list[int]:
        """Stub — returns candidates in original order."""
        return candidates

    @property
    def name(self) -> str:
        return "dqn"
