"""PPO Agent — stub with BaseAgent interface."""

from __future__ import annotations

from typing import Any

from deeprl_recsys.agents.base import BaseAgent


class PPOAgent(BaseAgent):
    """Proximal Policy Optimization agent (stub)."""

    def __init__(self, **kwargs: Any) -> None:
        self._config = kwargs

    def act(self, observation: dict[str, Any], candidates: list[int]) -> list[int]:
        return candidates

    @property
    def name(self) -> str:
        return "ppo"
