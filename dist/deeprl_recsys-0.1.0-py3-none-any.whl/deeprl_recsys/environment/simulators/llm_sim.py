"""LLM-based simulator — requires extra [llm].

Do NOT import this module unless the [llm] extra is installed.
"""

from __future__ import annotations

from typing import Any

from deeprl_recsys.environment.simulators.base_sim import BaseSimulator


class LLMSimulator(BaseSimulator):
    """Simulates user responses using an LLM (stub).

    Requires: ``pip install deeprl-recsys[llm]``
    """

    def __init__(self, **kwargs: Any) -> None:
        try:
            import transformers  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "LLMSimulator requires the [llm] extra. "
                "Install with: pip install deeprl-recsys[llm]"
            ) from exc
        self._config = kwargs

    def simulate_response(self, user: dict[str, Any], item: int) -> float:
        return 0.0  # Stub
